from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET,collections,subprocess,sys
head='9ae613946cbc7b560bc0e9a2504a520fedaebc03';tree='fc2d0a6394aeddac6a4ebff75bcabbd7c9f2fe44'
base=ET.parse('/tmp/aun-repro-public-final/artifact/bounded-full.xml').getroot()
mapping=json.loads(Path('docs/verify/aun-v2-nonpersistence-20260921/down1-ownership-contract/preservation.json').read_text())['authorized_case_mapping']
key=lambda c:(c.get('file'),c.get('classname'),c.get('name'))
def keys(root,skips=False,remap=False):
 items=[]
 for c in root.iter('testcase'):
  if skips and c.find('skipped') is None:continue
  a=list(key(c))
  if remap:a[2]=mapping.get(a[2],a[2])
  items.append(tuple(a))
 return collections.Counter(items)
root=Path(sys.argv[1]);art=next((root/'artifact').rglob('bounded-ci-subject.json')).parent
subject=json.loads((art/'bounded-ci-subject.json').read_text())
assert subject['candidate_head']==head and subject['candidate_tree']==tree and subject['tested_tree']==tree,subject
assert head in subject['tested_parents'],subject
sha=hashlib.sha256();cmd=subprocess.Popen(['git','diff','--binary','--full-index',subject['base']+'...'+head],stdout=subprocess.PIPE)
while chunk:=cmd.stdout.read(1024*1024):sha.update(chunk)
assert cmd.wait()==0 and sha.hexdigest()==subject['binary_diff_sha256']
reports={}
for p in art.glob('*.xml'):
 xml=ET.parse(p).getroot();cs=list(xml.iter('testcase'))
 reports[p.name]={'root':xml.attrib,'pass':sum(not any(x.tag in ('failure','error','skipped') for x in c) for c in cs),'fail':sum(any(x.tag in ('failure','error') for x in c) for c in cs),'skip':sum(c.find('skipped') is not None for c in cs),'failed':[c.attrib for c in cs if c.find('failure') is not None or c.find('error') is not None]}
full=ET.parse(art/'bounded-full.xml').getroot()
missing=keys(base,remap=True)-keys(full);extra=keys(full)-keys(base,remap=True)
skips_equal=keys(base,skips=True)==keys(full,skips=True)
standalone={p:info for p,info in reports.items() if p.startswith('repro-')}
assert len(standalone)==6
for p,v in standalone.items():assert v['pass']==1 and v['fail']==0,(p,v)
# Every standalone case must also pass under the complete suite.
full_cases={key(c):c for c in full.iter('testcase')}
for p in standalone:
 c=next(c for c in ET.parse(art/p).getroot().iter('testcase') if c.find('skipped') is None)
 assert key(c) in full_cases,key(c)
 assert not any(x.tag in ('failure','error','skipped') for x in full_cases[key(c)]),key(c)
regression_sets={}
full_pass=collections.Counter((c.get('classname','')+' > ' if c.get('classname') else '')+c.get('name','') for c in full.iter('testcase') if not any(x.tag in ('failure','error','skipped') for x in c))
for n,count in [('regression1-final-repair.log',166),('regression2-final-repair.log',59)]:
 names=json.loads(Path('/tmp/aun-down1-public/baseline',n+'.case-names.json').read_text())
 assert len(names)==count
 absent=collections.Counter(names)-full_pass
 regression_sets[n]={'denominator':count,'missing_or_not_passed':dict(absent)}
 assert not absent,(n,absent)
log=(root/'job.log').read_text();diagnostics=[]
for line in log.splitlines():
 m=re.search(r'(\{"case":"NP04-(?:startup-replay-D-OWN-1|actual-server-startup)".*)',line)
 if m:
  try:diagnostics.append(json.loads(m[1]))
  except json.JSONDecodeError:pass
for d in diagnostics:
 if d['case']=='NP04-startup-replay-D-OWN-1':
  assert d['original']['publications']==1 and d['replacement']['publications']==d['replacement']['work']==0
  assert d['replacement']['errors']==['RUNTIME_ENDPOINT_REGISTRATION_FAILED','RUNTIME_UUID_ALREADY_REGISTERED']
summary=[line for line in log.splitlines() if 'Run full test suite\t' in line and re.search(r'\b(?:\d+ pass|\d+ fail|\d+ skip|\d+ expect\(\) calls|Ran \d+ tests)',line)]
result={'regression_sets':regression_sets,'subject':subject,'reports':reports,'old_full_cases_missing':[list(k)+[v] for k,v in missing.items()],'additional_cases':[list(k)+[v] for k,v in extra.items()],
'original_59_skip_multiset_equal':skips_equal,'diagnostics':diagnostics,'full_summary':summary,
'raw_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}}
(root/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'reports':reports,'old_missing':result['old_full_cases_missing'],'additional':len(extra),'skip_multiset_equal':skips_equal,'diagnostics':len(diagnostics),'summary':summary},ensure_ascii=False))
assert not missing and skips_equal
assert reports['bounded-full.xml']['fail']==0
