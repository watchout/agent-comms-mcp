import { Client } from '/Users/yuji/Developer/.worktrees/agent-comms-aun-v2-trial-ready-20260921/node_modules/pg/lib/index.js'
import { readFileSync } from 'node:fs'
const env=JSON.parse(readFileSync('/tmp/aun-trial-ready-pg-env.json','utf8'))
const client=new Client({connectionString:env.DATABASE_URL});await client.connect()
try {
 const identity=(await client.query("SELECT current_database() db,current_user actor,current_setting('listen_addresses') listen,current_setting('unix_socket_directories') socket")).rows[0]
 if(identity.db!=='aun_trial_ready_test'||identity.actor!=='fixture'||identity.listen!==''||identity.socket!=='/private/tmp/aun-independent-pg-7i5o4k48/socket')throw Error('OWNED_FIXTURE_REQUIRED')
 const expiry=(await client.query("SELECT '2026-09-22T00:00:00.123456Z'::timestamptz AS expiry")).rows[0].expiry
 const result=(await client.query("SELECT '2026-09-22T00:00:00.123200Z'::timestamptz > $1::timestamptz AS via_js_date, '2026-09-22T00:00:00.123200Z'::timestamptz > '2026-09-22T00:00:00.123456Z'::timestamptz AS via_database_timestamp",[expiry])).rows[0]
 if(result.via_js_date!==true||result.via_database_timestamp!==false)throw Error('PRECISION_COUNTEREXAMPLE_NOT_REPRODUCED')
 console.log(JSON.stringify({identity,database_expiry:'2026-09-22T00:00:00.123456Z',driver_date:expiry.toISOString(),probe_clock:'2026-09-22T00:00:00.123200Z',...result,db_writes:0}))
}finally{await client.end()}
